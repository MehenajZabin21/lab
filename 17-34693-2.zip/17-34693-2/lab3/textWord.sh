Hasin is a good boy.Though he hates Muhit.
