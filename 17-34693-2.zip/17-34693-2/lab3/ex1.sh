clear
echo “Input Value of a  b :”
read a
read b
c= expr $a + $b
echo $c